#!/bin/bash

rm -rf /tmp/spool/*